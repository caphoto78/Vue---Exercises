<template>
  <div class="container-fluid">
    <div class="row">
      <form-component></form-component>
      <maze-component v-if="formIsSubmitted"></maze-component>
    </div>
  </div>
</template>

<script>
// @ is an alias to /src
import MazeComponent from '../components/MazeComponent.vue';
import FormComponent from '../components/FormComponent.vue';
import { mapGetters } from 'vuex';

export default {
  name: "Home",
  components: {
    FormComponent,
    MazeComponent,
  },
  computed: {
    ...mapGetters(['formIsSubmitted']),
  },
  data() {
    return {
    }
  },
};
</script>
