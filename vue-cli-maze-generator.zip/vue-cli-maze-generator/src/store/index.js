import Vue from "vue";
import Vuex from "vuex";

Vue.use(Vuex);

export default new Vuex.Store({
  state: {
    formIsSubmitted: false,
    formData: {
      width: 0,
      height: 0,
      start: 0,
      end: 0,
      density: 0
    }
  },
  mutations: {
    SUBMIT_FORM(state) {
      state.formIsSubmitted = true
    },
    UPDATE_DATA(state, payload) {
      state.formData = payload;
    }
  },
  actions: {
    submitForm({ commit }) {
      commit('SUBMIT_FORM');
    }
  },
  getters: {
    formIsSubmitted(state) {
      return state.formIsSubmitted;
    },
    getFormData(state) {
      return state.formData;
    }
  }
});
