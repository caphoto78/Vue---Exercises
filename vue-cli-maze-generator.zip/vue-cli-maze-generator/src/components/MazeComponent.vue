<template>
  <div class="card mx-auto" style="width: 30rem">
    <div class="card-body">
      <canvas class="maze"></canvas>
    </div>
  </div>
</template>

<script>
  import { mapGetters } from 'vuex';
  export default {
    computed: {
      ...mapGetters(['getFormData'])
    },

    mounted() {
      // Generare labirint folosind algoritmul 'depth-first-search'

      // • Given a current cell as a parameter,
      // • Mark the current cell as visited
      // • While the current cell has any unvisited neighbour cells
      //    - Choose one of the unvisited neighbours
      //    - Remove the wall between the current cell and the chosen cell
      //    - Invoke the routine recursively for a chosen cell
      //      which is invoked once for any initial cell in the area.

      // initializez canvas-ul si setez contextul

      let maze = document.querySelector(".maze");
      let ctx = maze.getContext("2d");
      // let generationComplete = false;

      let current;
      // let goal;

      // definim doua clase si setam proprietatile si metodele: Maze && Cell
      // Maze:  size = dimensiunea in pizeli a labirintului
      //        rows = numarul de randuri
      //        columns = numarul de coloane
      //        grid = matricea 2D

      class Maze {
        constructor(mazeWidth, mazeHeight, rows, columns) {
          this.mazeWidth = mazeWidth;
          this.mazeHeight = mazeHeight;
          this.rows = rows;
          this.columns = columns;

          this.grid = [];
          this.stack = [];
        }

        // setez gridul in canvas si desenez fiecare celula pe gridul creeat
        setup() {
          for (let r = 0; r < this.rows; r++) {
            let row = [];
            for (let c = 0; c < this.columns; c++) {
              let cell = new Cell(r, c, this.grid, this.mazeWidth, this.mazeHeight);
              row.push(cell);
            }
            this.grid.push(row)
          }
          current = this.grid[0][0];
          this.grid[this.rows - 1][this.columns - 1].goal = true;
        }

        // algoritmul propiu-zis de generare al labirintului

        draw() {
          maze.width = this.mazeWidth;
          maze.height = this.mazeHeight
          maze.style.background = 'black';
          current.visited = true;

          for (let r = 0; r < this.rows; r++) {
            for (let c = 0; c < this.columns; c++) {
              let grid = this.grid;
              grid[r][c].show(this.mazeWidth, this.mazeHeight, this.rows, this.columns);
            }
          }
          let next = current.checkNeighbours();

          if (next) {
            next.visited = true;

            this.stack.push(current);

            current.highlight(this.columns, this.rows);

            current.removeWalls(current, next);

            current = next;
          } else if (this.stack.length > 0) {
            let cell = this.stack.pop();
            current = cell;
            current.highlight(this.columns, this.rows);
          }

          if (this.stack.length === 0) {
            // generationComplete = true;
            return;
          }

          window.requestAnimationFrame(() => {
            this.draw();
            // setTimeout(() => {
            //   this.draw();
            // }, 1000);
          });
        }
      }

      // definim Cell Class unde:
      // rowNum = indexul X al celulei
      // colNum = indexul Y al celulei
      // parentGrid = gridul din clasa Maze
      // parentSize = marimea maze-ului in pixeli

      class Cell {
        constructor(rowNum, colNum, parentGrid, parentWidthSize, parentHeightSize) {
          this.rowNum = rowNum;
          this.colNum = colNum;
          this.visited = false;
          this.walls = {
            topWall: true,
            rightWall: true,
            bottomWall: true,
            leftWall: true,
          };
          this.goal = false;
          this.parentGrid = parentGrid;
          this.parentWidthSize = parentWidthSize;
          this.parentHeightSize = parentHeightSize;
        }

        // Metoda care seteaza vecinii celulei si returneaza un vecin ales aleatoriu

        checkNeighbours() {
          let grid = this.parentGrid;
          let row = this.rowNum;
          let col = this.colNum;
          let neighbors = [];

          let top = row !== 0 ? grid[row - 1][col] : undefined;
          let right = col !== grid.length - 1 ? grid[row][col + 1] : undefined;
          let bottom = row !== grid.length - 1 ? grid[row + 1][col] : undefined;
          let left = col !== 0 ? grid[row][col - 1] : undefined;

          if (top && !top.visited) neighbors.push(top);
          if (right && !right.visited) neighbors.push(right);
          if (bottom && !bottom.visited) neighbors.push(bottom);
          if (left && !left.visited) neighbors.push(left);

          if (neighbors.length !== 0) {
            let random = Math.floor(Math.random() * neighbors.length);
            return neighbors[random];
          } else {
            return undefined;
          }
        }

        // Metodele care deseneaza muchiile (peretii) celulei

        drawTopWall(x, y, width, height, columns, ) {
          ctx.beginPath();
          ctx.moveTo(x, y);
          ctx.lineTo(x + width / columns, y);
          ctx.stroke();
        }
        drawRightWall(x, y, width, height, columns, rows) {
          ctx.beginPath();
          ctx.moveTo(x + width / columns, y);
          ctx.lineTo(x + width / columns, y + height / rows);
          ctx.stroke();
        }
        drawBottomWall(x, y, width, height, columns, rows) {
          ctx.beginPath();
          ctx.moveTo(x, y + height / rows);
          ctx.lineTo(x + width / columns, y + height / rows);
          ctx.stroke();
        }
        drawLeftWall(x, y, width, height, columns, rows) {
          ctx.beginPath();
          ctx.moveTo(x, y);
          ctx.lineTo(x, y + height / rows);
          ctx.stroke();
        }

        // metoda care evidentiaza vizual celula curenta

        highlight(columns, rows) {
          let x = (this.colNum * this.parentWidthSize) / columns + 1;
          let y = (this.rowNum * this.parentHeightSize) / rows + 1;

          ctx.fillStyle = 'purple';
          ctx.fillRect(
            x,
            y,
            this.parentWidthSize / columns - 3,
            this.parentHeightSize / rows - 3
          );
        }

        // Metoda care sterge muchia dintre doua celule vecine (adiacente)

        removeWalls(cell1, cell2) {
          let x = cell1.colNum - cell2.colNum;
          if (x === 1) {
            cell1.walls.leftWall = false;
            cell2.walls.rightWall = false;
          } else if (x === -1) {
            cell1.walls.rightWall = false;
            cell2.walls.leftWall = false;
          }

          let y = cell1.rowNum - cell2.rowNum;
          if (y === 1) {
            cell1.walls.topWall = false;
            cell2.walls.bottomWall = false;
          } else if (y === -1) {
            cell1.walls.bottomWall = false;
            cell2.walls.topWall = false;
          }
        }

        // metoda care initializeaza desenul prin aplicarea metodelor de desenare

        show(width, height, rows, columns) {
          let x = (this.colNum * width) / columns;
          let y = (this.rowNum * height) / rows;

          ctx.strokeStyle = 'white';
          ctx.fillStyle = 'black';
          ctx.lineWidth = 2;

          if (this.walls.topWall) this.drawTopWall(x, y, width, height, columns, rows);
          if (this.walls.rightWall) this.drawRightWall(x, y, width, height, columns, rows);
          if (this.walls.bottomWall) this.drawBottomWall(x, y, width, height, columns, rows);
          if (this.walls.leftWall) this.drawLeftWall(x, y, width, height, columns, rows);
          if (this.visited) {
            ctx.fillRect(x + 1, y + 1, width / columns - 2, height / rows - 2);
          }
          if (this.goal) {
            ctx.fillStyle = "rgb(83, 247, 43)";
            ctx.fillRect(x + 1, y + 1, width / columns - 2, height / rows - 2);
          }
        }
      }

      // initializez labirintul si il populez  cu celule

      let newMaze = new Maze(500, 500, 10, 10);
      newMaze.setup();
      newMaze.draw();
    },
  }
  </script>

<style>

</style>