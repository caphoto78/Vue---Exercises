<template>
  <div class="card mx-auto" style="width: 30rem">
    <div class="card-body">
      <form @submit.prevent="submitForm">
          <h1>Maze Generator</h1>
          <p>Please set your parameters to generate a new maze.</p>
        <div class="row">
          <div class="col form-group">
            <label for="width" class="col-form-label col-form-label-sm">Width: </label>
            <input
              v-model="width"
              class="form-control form-control-sm"
              type="number"
              name="width"
              placeholder="Set the width of the canvas...">
              <!-- <p>{{ width }}</p> -->
          </div>
          <div class="col form-group">
            <label for="height" class="col-form-label col-form-label-sm">Height: </label>
            <input
              class="form-control form-control-sm"
              type="number"
              name="height"
              placeholder="Set the height of the canvas..."
              v-model="height">
              <!-- <p>{{ height }}</p> -->
          </div>
        </div>
          
          <div class="form-group">
            <label for="start" class="col-form-label col-form-label-sm">Start Coordinates: </label>
            <input
              class="form-control form-control-sm"
              type="number"
              name="start"
              placeholder="Set the starting point..."
              v-model="start">
          </div>
          <div class="form-group">
            <label for="end" class="col-form-label col-form-label-sm">End Coordinates: </label>
            <input
              class="form-control form-control-sm"
              type="number"
              name="end"
              placeholder="Set the ending point..."
              v-model="end">
          </div>
          <div class="form-group">
            <label for="density" class="col-form-label col-form-label-sm">Density: </label>
            <input
              class="form-control form-control-sm"
              type="number"
              name="density"
              placeholder="Set the brick density..."
              v-model="density">
          </div>

          <button type="submit" class="btn btn-primary btn-sm">Generate your maze...</button>
      </form>
    </div>
  </div>
</template>

<script>
import { mapActions } from 'vuex';
import { mapFields } from "../../model/helpers"

export default {
  data() {
    return {
      
    }
  },
  computed: {
    ...mapFields({
      fields: ["width", "height", "start", "end", "density"],
      base: "formData",
      mutation: "UPDATE_DATA"
    })
  },
  methods: {
    ...mapActions(['submitForm']),
  },
}
</script>

<style scoped>
</style>